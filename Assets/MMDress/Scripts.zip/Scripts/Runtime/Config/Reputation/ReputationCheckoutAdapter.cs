using UnityEngine;
using MMDress.Runtime.Reputation;

namespace MMDress.Runtime.Integration
{
    /// Tempel di prefab Customer. 
    /// Panggil SetEquippedCount() dari flow-mu (mis. sesaat sebelum close Fitting/checkout).
    public sealed class CustomerReputationReporter : MonoBehaviour
    {
        [SerializeField] private ReputationService reputation;

        private int _equippedCount;
        private bool _reported;

        public void SetEquippedCount(int count)
        {
            _equippedCount = Mathf.Max(0, count);
        }

        private void OnDisable() { ReportOnce(); }   // jalan di pooling
        private void OnDestroy() { ReportOnce(); }   // jaga-jaga kalau destroy

        private void ReportOnce()
        {
            if (_reported || reputation == null) return;

            bool served = _equippedCount > 0;
            reputation.ApplyCheckout(served: served, empty: !served);
            _reported = true; // anti dobel
        }
    }
}
