namespace MMDress.Runtime.Inventory
{
    public enum MaterialType { Cloth, Thread }
    public enum GarmentSlot { Top, Bottom }
}
