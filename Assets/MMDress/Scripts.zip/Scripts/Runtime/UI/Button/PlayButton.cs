using UnityEngine;

public class PlayButton : MonoBehaviour
{
    public void OnPlayButton()
    {
        TutorialRouter.StartGame();
    }
}
