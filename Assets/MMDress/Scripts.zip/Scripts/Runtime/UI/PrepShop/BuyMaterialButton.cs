﻿// ===============================
// File: Assets/MMDress/Scripts/Runtime/UI/PrepShop/BuyMaterialButton.cs
// ===============================
using UnityEngine;
using UnityEngine.UI;
using MMDress.Services;
using MMDress.Data;
using MMDress.Runtime.Inventory;

namespace MMDress.Runtime.UI.PrepShop
{
    [DisallowMultipleComponent]
    public sealed class BuyMaterialButton : MonoBehaviour
    {
        [SerializeField] private Button button;
        [SerializeField] private ProcurementService procurement;

        [Header("Pilihan Material (salah satu wajib diisi)")]
        [SerializeField] private MaterialSO materialSO;
        [SerializeField] private MaterialType materialEnum = MaterialType.Cloth;

        [SerializeField, Min(1)] private int quantity = 1;
        [SerializeField] private bool useMaterialSO = true;

        void Reset()
        {
            button ??= GetComponent<Button>();
            procurement ??= FindObjectOfType<ProcurementService>(true);
        }

        void Awake()
        {
            if (button) button.onClick.AddListener(OnClickBuy);
        }

        void OnClickBuy()
        {
            if (!procurement || quantity <= 0) return;

            if (useMaterialSO && materialSO != null)
            {
                procurement.BuyMaterial(materialSO, quantity);
            }
            else
            {
                procurement.BuyMaterial(materialEnum, quantity);
            }
        }
    }
}