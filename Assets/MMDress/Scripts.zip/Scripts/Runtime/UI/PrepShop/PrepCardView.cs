// Assets/MMDress/Scripts/Runtime/UI/PrepShop/PrepCardView.cs
using System;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using MMDress.Data;

namespace MMDress.Runtime.UI.PrepShop
{
    [DisallowMultipleComponent]
    public sealed class PrepCardView : MonoBehaviour
    {
        [Header("UI")]
        [SerializeField] private Image iconImage;
        [SerializeField] private TMP_Text qtyText;
        [SerializeField] private Button plusButton;
        [SerializeField] private Button minusButton;

        [Header("State Visual")]
        [SerializeField, Range(0.2f, 1f)] private float enabledAlpha = 1f;
        [SerializeField, Range(0.1f, 0.9f)] private float disabledAlpha = 0.45f;

        [Header("Manual Mapping (optional)")]
        [SerializeField] private bool useManualIndex = false;
        [SerializeField] private OutfitSlot manualSlot = OutfitSlot.Top;
        [SerializeField] private int manualRelativeIndex = -1; // index relatif dalam slot

        [NonSerialized] public OutfitSlot slot = OutfitSlot.Top;
        [NonSerialized] public int typeIndex = -1;

        private int _planned;

        public event Action<PrepCardView, int> OnDelta; // +1 / -1

        void Awake()
        {
            // Terapkan mapping manual duluan (kalau diaktifkan)
            if (useManualIndex && manualRelativeIndex >= 0)
            {
                slot = manualSlot;
                typeIndex = manualRelativeIndex;
            }

            if (plusButton) plusButton.onClick.AddListener(() => OnDelta?.Invoke(this, +1));
            if (minusButton) minusButton.onClick.AddListener(() =>
            {
                if (_planned > 0) OnDelta?.Invoke(this, -1);
            });
        }

        /// Dipakai panel saat build dari Theme (diabaikan jika useManualIndex aktif).
        public void Bind(Sprite icon, OutfitSlot s, int typeIdx, int initialPlan = 0)
        {
            if (!useManualIndex)
            {
                slot = s;
                typeIndex = typeIdx;
            }

            if (iconImage)
            {
                iconImage.sprite = icon;
                iconImage.enabled = icon != null;
                iconImage.type = Image.Type.Simple;
                iconImage.preserveAspect = true;
                var c = iconImage.color; c.a = icon ? enabledAlpha : disabledAlpha; iconImage.color = c;
            }

            SetPlanned(Mathf.Max(0, initialPlan));
        }

        public void SetPlanned(int qty)
        {
            _planned = Mathf.Max(0, qty);
            if (qtyText) qtyText.text = _planned.ToString();
            if (minusButton) minusButton.interactable = _planned > 0;
        }

        // buat panel ngecek apakah card ini pakai manual index
        public bool UsesManualIndex => useManualIndex;
    }
}
