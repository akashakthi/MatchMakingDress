﻿// Assets/MMDress/Scripts/Runtime/UI/PrepShop/PrepShopManualPanel.cs
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using MMDress.Data;
using MMDress.Runtime.Inventory;
using MMDress.Services;

// alias (kalau nanti butuh subscribe ke service events)
using SvcPurchaseSucceeded = MMDress.Services.PurchaseSucceeded;
using SvcCraftSucceeded = MMDress.Services.CraftSucceeded;

using InvMaterialType = MMDress.Runtime.Inventory.MaterialType;

namespace MMDress.Runtime.UI.PrepShop
{
    [DisallowMultipleComponent]
    public sealed class PrepShopManualPanel : MonoBehaviour
    {
        [Header("Refs")]
        [SerializeField] private ProcurementService procurement;
        [SerializeField] private PrepPanelTheme theme;  // optional

        [Header("Top Cards (maks 5)")]
        [SerializeField] private PrepCardView[] topCards = new PrepCardView[5];

        [Header("Bottom Cards (maks 5)")]
        [SerializeField] private PrepCardView[] bottomCards = new PrepCardView[5];

        [Header("Header UI")]
        [SerializeField] private TMP_Text clothText;
        [SerializeField] private TMP_Text threadText;
        [SerializeField] private TMP_Text moneyText;

        [Header("Footer Preview")]
        [SerializeField] private TMP_Text needClothText;
        [SerializeField] private TMP_Text needThreadText;
        [SerializeField] private TMP_Text warningText;

        // rencana: (slot, relativeTypeIndex) -> qty
        private readonly Dictionary<(OutfitSlot, int), int> _plan = new();

        // snapshot saat panel dibuka/enable
        int _snapCloth, _snapThread, _snapMoney;

        void Reset()
        {
            if (!procurement) procurement = FindObjectOfType<ProcurementService>(true);
        }

        void Awake()
        {
            BuildFromThemeOrManual();
            Snapshot();
            RefreshHeader();
            RefreshPreview();
        }

        void OnEnable()
        {
            Snapshot();
            RefreshHeader();
            RefreshPreview();
        }

        // ==============================================
        // Build card mapping: Theme kalau ada & card TIDAK manual
        // ==============================================
        void BuildFromThemeOrManual()
        {
            // TOP
            for (int i = 0; i < topCards.Length; i++)
            {
                var card = topCards[i];
                if (!card) continue;

                if (theme && !card.UsesManualIndex)
                {
                    var e = theme.GetTop(i);
                    int rel = ToRelativeIndex(OutfitSlot.Top, e.typeIndex);
                    card.Bind(e.icon, OutfitSlot.Top, rel, 0);
                }
                // kalau UsesManualIndex = true → mapping sudah terpasang di Awake card

                card.OnDelta += OnCardDelta;
                // pastikan key terdaftar
                var key = (card.slot, Mathf.Max(0, card.typeIndex));
                if (!_plan.ContainsKey(key)) _plan[key] = 0;
            }

            // BOTTOM
            for (int i = 0; i < bottomCards.Length; i++)
            {
                var card = bottomCards[i];
                if (!card) continue;

                if (theme && !card.UsesManualIndex)
                {
                    var e = theme.GetBottom(i);
                    int rel = ToRelativeIndex(OutfitSlot.Bottom, e.typeIndex);
                    card.Bind(e.icon, OutfitSlot.Bottom, rel, 0);
                }

                card.OnDelta += OnCardDelta;
                var key = (card.slot, Mathf.Max(0, card.typeIndex));
                if (!_plan.ContainsKey(key)) _plan[key] = 0;
            }
        }

        int ToRelativeIndex(OutfitSlot slot, int themeIndex)
        {
            int topCount = procurement ? procurement.GetTopTypes() : 0;
            if (slot == OutfitSlot.Top) return Mathf.Max(0, themeIndex);
            return Mathf.Max(0, themeIndex - topCount); // bottom di Theme memakai offset Top
        }

        // ==============================================
        // Snapshot & Header
        // ==============================================
        void Snapshot()
        {
            _snapCloth = procurement ? procurement.GetMaterial(InvMaterialType.Cloth) : 0;
            _snapThread = procurement ? procurement.GetMaterial(InvMaterialType.Thread) : 0;
            _snapMoney = procurement && procurement.TryGetEconomy(out var eco) ? eco.Balance : 0;
        }

        void RefreshHeader()
        {
            if (clothText) clothText.text = _snapCloth.ToString();
            if (threadText) threadText.text = _snapThread.ToString();
            if (moneyText) moneyText.text = $"Rp {_snapMoney:N0}";
        }

        // ==============================================
        // Planning helpers
        // ==============================================
        int TotalPlanned()
        {
            int t = 0;
            foreach (var kv in _plan) t += kv.Value;
            return t;
        }

        int AvailablePairs() => Mathf.Min(_snapCloth, _snapThread);

        void RefreshPreview()
        {
            int planned = TotalPlanned();
            int needCloth = Mathf.Max(0, planned - _snapCloth);
            int needThread = Mathf.Max(0, planned - _snapThread);

            if (needClothText) needClothText.text = needCloth.ToString();
            if (needThreadText) needThreadText.text = needThread.ToString();

            bool ok = planned <= AvailablePairs();
            if (warningText)
            {
                warningText.text = ok ? "" : "Bahan tidak cukup (1 kain + 1 benang / item).";
                warningText.color = ok ? new Color(1, 1, 1, 0) : new Color(1f, .3f, .3f, 1f);
            }
        }

        // ==============================================
        // Card callbacks (+/-)
        // ==============================================
        void OnCardDelta(PrepCardView view, int delta)
        {
            if (!view || view.typeIndex < 0) return;

            var key = (view.slot, view.typeIndex);
            int cur = _plan.TryGetValue(key, out var v) ? v : 0;

            if (delta > 0)
            {
                // clamp berdasar bahan
                if (TotalPlanned() >= AvailablePairs()) return;
                cur += 1;
            }
            else
            {
                if (cur <= 0) return;
                cur -= 1;
            }

            _plan[key] = cur;
            view.SetPlanned(cur);
            RefreshPreview();
        }

        // ==============================================
        // Commit (hubungkan ke tombol "Mulai Berjualan!")
        // ==============================================
        public void OnClickCommitCraft()
        {
            if (!procurement) return;

            // craft semua rencana
            foreach (var kv in _plan)
            {
                var (slot, relIdx) = kv.Key;
                int qty = kv.Value;
                if (qty <= 0) continue;

                procurement.Craft(
                    slot == OutfitSlot.Top ? GarmentSlot.Top : GarmentSlot.Bottom,
                    relIdx,
                    qty
                );
            }

            // reset plan visual & data
            foreach (var top in topCards) if (top) top.SetPlanned(0);
            foreach (var bottom in bottomCards) if (bottom) bottom.SetPlanned(0);
            _plan.Clear(); // bersihkan dan reinit key sesuai card aktif
            BuildFromThemeOrManual();

            // ambil ulang stok (kain/benang pasti berkurang setelah craft)
            Snapshot();
            RefreshHeader();
            RefreshPreview();

            Debug.Log("[PrepShop] Craft commit done.");
        }
    }
}
