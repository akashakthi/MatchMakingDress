﻿using UnityEngine;
using UnityEngine.UI;
using MMDress.Core;
using MMDress.Gameplay;
using MMDress.Data;

namespace MMDress.UI
{
    /// UI Fitting (1 list horizontal + filter kategori):
    /// - Klik Baju/Rok -> list memuat item slot terkait
    /// - Klik item -> preview di karakter (publish OutfitPreviewChanged)
    /// - Equip -> commit 1 item preview aktif (publish OutfitEquippedCommitted)
    /// - Close -> EquipAllPreview + (opsional) publish equip per slot + lanjut flow customer leave
    [DisallowMultipleComponent]
    [AddComponentMenu("MMDress/UI/Fitting Room UI")]
    public sealed class FittingRoomUI : MonoBehaviour
    {
        #region Inspector

        [Header("Panel Root")]
        [SerializeField] private GameObject panelRoot;

        [Header("Data")]
        [SerializeField] private CatalogSO catalog;

        [Header("List (Horizontal)")]
        [SerializeField] private ItemGridView listView;   // pengganti TopGrid/BottomGrid

        [Header("Buttons")]
        [SerializeField] private Button tabTopButton;
        [SerializeField] private Button tabBottomButton;
        [SerializeField] private Button equipButton;
        [SerializeField] private Button closeButton;

        [Header("Options")]
        [SerializeField] private bool autoFindInChildren = true;
        [SerializeField] private bool publishEquipOnClose = true; // modular

        #endregion

        #region Runtime

        private Customer.CustomerController _current;
        private ItemSO _previewItem;
        private OutfitSlot _activeTab = OutfitSlot.Top;

        #endregion

        #region Unity

        private void Awake()
        {
            if (autoFindInChildren && !listView)
                listView = GetComponentInChildren<ItemGridView>(true);

            if (tabTopButton) tabTopButton.onClick.AddListener(() => ShowTab(OutfitSlot.Top));
            if (tabBottomButton) tabBottomButton.onClick.AddListener(() => ShowTab(OutfitSlot.Bottom));
            if (equipButton) equipButton.onClick.AddListener(EquipPreview);
            if (closeButton) closeButton.onClick.AddListener(Close);

            if (listView != null)
                listView.OnItemSelected = OnItemClicked;

            if (panelRoot) panelRoot.SetActive(false);
        }

        #endregion

        #region External API (dipanggil spawner/customer)

        public void Open(Customer.CustomerController target)
        {
            _current = target;
            _previewItem = null;

            if (panelRoot) panelRoot.SetActive(true);
            ShowTab(OutfitSlot.Top);

            ServiceLocator.Events.Publish(new FittingUIOpened());
            UpdateEquipButton();
        }

        #endregion

        #region Callbacks

        private void OnItemClicked(ItemSO item)
        {
            _previewItem = item;
            _current?.Outfit.TryOn(item); // preview di karakter

            // === PREVIEW EVENT (baru, terpisah) ===
            ServiceLocator.Events.Publish(
                new OutfitPreviewChanged(_current, item.slot, item)
            );

            UpdateEquipButton();
        }

        #endregion

        #region UI logic

        private void ShowTab(OutfitSlot slot)
        {
            _activeTab = slot;

            if (listView)
            {
                listView.SetCatalog(catalog);
                listView.SetSlot(slot);
                var equipped = _current ? _current.Outfit.GetEquipped(slot) : null;
                listView.Refresh(equipped);
            }

            if (tabTopButton) tabTopButton.interactable = (slot != OutfitSlot.Top);
            if (tabBottomButton) tabBottomButton.interactable = (slot != OutfitSlot.Bottom);

            UpdateEquipButton();
        }

        private void UpdateEquipButton()
        {
            if (equipButton) equipButton.interactable = (_previewItem != null);
        }

        private void EquipPreview()
        {
            if (_current == null || _previewItem == null) return;

            _current.Outfit.Equip(_previewItem);

            // === EQUIP EVENT (baru, terpisah) ===
            ServiceLocator.Events.Publish(
                new OutfitEquippedCommitted(_current, _previewItem.slot, _previewItem)
            );

            _previewItem = null;
            UpdateEquipButton();
        }

        public void Close()
        {
            if (_current != null)
            {
                // commit semua preview jadi equip
                _current.Outfit.EquipAllPreview();

                // publish equip final per slot (modular)
                if (publishEquipOnClose)
                {
                    var top = _current.Outfit.GetEquipped(OutfitSlot.Top);
                    var bot = _current.Outfit.GetEquipped(OutfitSlot.Bottom);

                    if (top) ServiceLocator.Events.Publish(new OutfitEquippedCommitted(_current, OutfitSlot.Top, top));
                    if (bot) ServiceLocator.Events.Publish(new OutfitEquippedCommitted(_current, OutfitSlot.Bottom, bot));
                }

                _current.FinishFitting();
            }

            ServiceLocator.Events.Publish(new FittingUIClosed());
            _current = null;
            _previewItem = null;
            if (panelRoot) panelRoot.SetActive(false);
        }

        #endregion
    }
}
