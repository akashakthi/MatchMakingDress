﻿using System;
using UnityEngine;
using UnityEngine.UI;
using TMPro;                 // penting
using MMDress.Data;

namespace MMDress.UI
{
    [DisallowMultipleComponent]
    public sealed class ItemButtonView : MonoBehaviour
    {
        [Header("UI")]
        [SerializeField] private Button button;
        [SerializeField] private Image icon;
        [SerializeField] private TMP_Text label;      // opsional, boleh kosong
        [SerializeField] private TMP_Text stockText;  // wajib: tampilkan sisa bahan (angka)

        [Header("Visual States")]
        [SerializeField, Range(0.2f, 1f)] private float enabledAlpha = 1f;
        [SerializeField, Range(0.1f, 0.9f)] private float disabledAlpha = 0.45f;
        [SerializeField] private bool disableWhenOutOfStock = true;

        private ItemSO _data;
        private int _stock = 0;
        public ItemSO Data => _data;

        public event Action<ItemSO> Clicked;

        void Awake()
        {
            if (button)
                button.onClick.AddListener(() =>
                {
                    if (_data != null && (_stock > 0 || !disableWhenOutOfStock))
                        Clicked?.Invoke(_data);
                });
        }

        /// <summary>Bind data item (ikon + nama). Stok tidak diubah di sini.</summary>
        public void Bind(ItemSO data)
        {
            _data = data;

            if (icon)
            {
                icon.sprite = data ? data.sprite : null;
                icon.enabled = icon.sprite != null;
                if (icon.preserveAspect && icon.sprite) icon.SetNativeSize();
                icon.type = Image.Type.Simple;
            }

            if (label) label.text = data ? data.displayName : "-";

            // tampilkan stok terakhir yang diketahui
            ApplyStockVisual(_stock);
        }

        /// <summary>Set sisa bahan (stok). Angka negatif dipaksa 0.</summary>
        public void BindStock(int stock)
        {
            _stock = Mathf.Max(0, stock);
            ApplyStockVisual(_stock);
        }

        private void ApplyStockVisual(int stock)
        {
            // 1) Tampilkan angka stok
            if (stockText)
                stockText.text = stock.ToString();

            // 2) Interactable & penggelapan saat stok 0
            bool hasStock = stock > 0;

            if (button && disableWhenOutOfStock)
                button.interactable = hasStock;

            float a = hasStock ? enabledAlpha : disabledAlpha;

            if (icon)
            {
                var c = icon.color;
                c.a = a;
                icon.color = c;
            }
            if (label)
            {
                var c = label.color;
                c.a = a;
                label.color = c;
            }
            if (stockText)
            {
                var c = stockText.color;
                c.a = a;
                stockText.color = c;
            }
        }

        /// <summary>Highlight seleksi (tanpa mengubah gelap/terang stok 0).</summary>
        public void SetSelected(bool on)
        {
            // jangan override darkening stok 0; cukup beri sedikit punch di icon kalau masih ada stok
            if (_stock <= 0 || icon == null) return;

            var c = icon.color;
            c.a = on ? Mathf.Min(1f, enabledAlpha) : enabledAlpha;
            icon.color = c;
        }
    }
}
