using UnityEngine;
using MMDress.Runtime.Reputation;

namespace MMDress.Runtime.Integration
{
    /// <summary>
    /// Tempel di prefab Customer. Panggil SetEquippedCount() dari flow-mu.
    /// Saat customer disable/destroy (pool/despawn), reputasi di-update sekali.
    /// </summary>
    public sealed class CheckoutReputationReporter : MonoBehaviour
    {
        [SerializeField] private ReputationService reputation;

        private int _equippedCount;
        private bool _reported;

        public void SetEquippedCount(int count)
        {
            _equippedCount = count < 0 ? 0 : count;
        }

        private void OnDisable() => ReportOnce();
        private void OnDestroy() => ReportOnce();

        private void ReportOnce()
        {
            if (_reported || reputation == null) return;

            bool served = _equippedCount > 0;
            reputation.ApplyCheckout(served: served, empty: !served);
            _reported = true;
        }
    }
}
